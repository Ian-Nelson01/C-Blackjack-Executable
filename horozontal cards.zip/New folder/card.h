﻿// Ian Nelson
// Nov 1st, 2022
// CS 361
// Assignment 6

// deck.h: Empty .h file


#include <iostream>
#include <ostream>
#pragma once
using namespace std;


// cards namespace definition with the cardSuit and CardValue enumerated variables
namespace cards {
    enum class cardSuit {
        spade, heart, diamond, club
    };
    enum class cardValue {
        Ace, Two, Three, Four, Five, Six, Seven, Eight, Nine, Ten, Jack, Queen, King
    };
}


class card {
public:
    card(cards::cardSuit mySuit, cards::cardValue myValue);
    card();
    void sketchCard(card inputCard);
    void setCardValue(cards::cardValue inputValue); // changes value
    cards::cardValue getCardValue();

    void setCardSuit(cards::cardSuit inputSuit); // changes value
    cards::cardSuit getCardSuit();

    friend std::ostream& operator << (std::ostream& os, card& myCard); // os is overwritten
    int valueConvert();
    int suitConvert();




    string cardBuilder[8] = { "01234567", "01234567","01234567", "01234567", "01234567", "01234567", "01234567", "01234567", };

private:
    cards::cardSuit secretSuit;
    cards::cardValue secretValue;
    /*
    string base[5] = {"╔══════╗", "║      ║", "║      ║", "║      ║", "╚══════╝"};

    string spades[3] = { "║  /\\  ║", "║ (  ) ║", "║  )(  ║" };
    string hearts[3] = { "║ /\\/\\ ║", "║ \\  / ║", "║  \\/  ║" };
    string clubs[3] = { "║  ()  ║", "║ ()() ║", "║  /\\  ║" };
    string diamonds[3] = { "║  /\\  ║", "║ <  > ║", "║  \\/  ║" };

    string back[5] = { "║┌────┐║", "║│ )( │║", "║│(  )│║", "║│ )( │║", "║└────┘║" };

    */









};

