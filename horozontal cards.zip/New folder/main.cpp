﻿// Ian Nelson
// Nov 15th, 2022
// CS 361
// Assignment 8

// main.cpp : This file contains the 'main' function. Program execution begins and ends there.


#include <iostream>
#include "card.h"
#include "deck.h"
#include "hand.h"

#include <memory>



using namespace std;



// compares player totals
void winFinder(int playerTotal, int dealerTotal) {
    if (playerTotal <= 21 && dealerTotal <= 21) {
        if (playerTotal > dealerTotal) {
            cout << "Player wins!" << endl;
        }
        else if (playerTotal < dealerTotal) {
            cout << "Dealer wins!" << endl;
        }
        else {
            cout << "Push, both player tie." << endl;
        }
    }
    else if (playerTotal <= 21 & dealerTotal > 21) {
        cout << "Dealer busted -- Player wins!" << endl;
    }
}


int main()
{
     

    
    // create deck
    deck theDeck;

    // create player hand
    std::unique_ptr<hand> myHand(new hand());
    // create dealer hand
    std::unique_ptr<hand> dHand(new hand());



    // deal first card
    myHand->addCardToHand(theDeck.dealCard());
    // deal first card
    dHand->addCardToHand(theDeck.dealCard());
    cout << "The dealer's up card is:" << endl;
    dHand->drawHand();
    // deal second card
    myHand->addCardToHand(theDeck.dealCard());
    // deal second card
    dHand->addCardToHand(theDeck.dealCard());


    // draw the hand
    cout << "The player's hand is:" << endl;
    myHand->drawHand();


   // check for blackjack
    if (myHand->handValueHigh() == 21) {
        cout << "Do you wish to hit (y/n)? ";
    }
   
    else {

        //String for input
        string inChoice = "hit";


        // loop plays out for players turn. allows players to hit or stay until bust.
        while (inChoice != "n" && inChoice != "out") {
            cout << "Do you wish to hit (y/n)? ";

            cin >> inChoice;
            if (inChoice == "y") {
                myHand->addCardToHand(theDeck.dealCard());
                myHand->drawHand();
            }
            else if (inChoice == "n") {
                break;
            }

            if (myHand->handValueLow() > 21) {
                cout << "The player busted and lost.";
                break;
            }
        }
    }


    // dealer makes use of choice string
    string inChoice = "hit";

    // dealer choices in loop, similar to player, loops until bust.
    while (inChoice != "stay" && inChoice != "out") {
        if (dHand->handValueHigh() <= 16) {
            dHand->addCardToHand(theDeck.dealCard());
        }
        else if (dHand->handValueHigh() >= 17 && dHand->handValueHigh() <= 21) {
            inChoice = "stay";

        }

        else if (dHand->handValueLow() > 21) {
            inChoice = "out";
        }

        // if hightotal is above 21, but low is below 21, it freaks out
        else if(dHand->handValueLow() <= 17  && dHand->handValueLow() > 21){
                     
            dHand->addCardToHand(theDeck.dealCard());
        }
        else {
            inChoice = "stay";
        }

    }


    // player totals found
    int playerTotal = 0;
    if (myHand->handValueHigh() <= 21) {
        playerTotal = myHand->handValueHigh();
    }
    else {
        playerTotal = myHand->handValueLow();
    }

    int dealerTotal = 0;
    if (dHand->handValueHigh() <= 21) {
        dealerTotal = dHand->handValueHigh();
    }
    else {
        dealerTotal = dHand->handValueLow();
    }



    // totals compared

    if (playerTotal <= 21) {
        cout << "The dealers hand is:" << endl;
        dHand->drawHand();

    }

    // win finder
    winFinder(playerTotal, dealerTotal);


    


}
