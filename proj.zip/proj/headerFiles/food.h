﻿// Ian Nelson
// Dec 2nd, 2022
// CS 361
// Assignment 10

// food.h: Declarations of food object

// preprocessing
#include <iostream>
#include <ostream>
#pragma once
using namespace std;


class food {
public:
    food();
    food(string inputName);
    string publicName; // this is public so it can be accessed via list.
};