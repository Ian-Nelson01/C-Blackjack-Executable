// Ian Nelson
// Dec 2nd, 2022
// CS 361
// Assignment 10

 // food.cpp: Uses a class file to create food objects



// Preprocessing Directives
//#pragma once
#include <iostream>
#include <ostream>
#include "food.h"
 
// default constructor
food::food(){
}

// string input constructor
food::food(string inputName) {
	publicName = inputName;
}