// Ian Nelson
// Dec 4th, 2022
// CS 361
// Assignment 10

// GList.h: declerations in an h file.

#pragma once
#include "food.h"
#include <list>
#include <algorithm>
#include <string>
#include <iterator>
#include <iostream>
using namespace std;



class GList {
public:
    GList(); // default constructor
    void addFood(food inputFood); // getter  
    void subFood(); // getter 
    void printList(); // printer

private:
    std::list<food> foodList;
};

