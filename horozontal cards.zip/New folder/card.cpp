

/*
 Ian Nelson
 CS 361
 Assignment 4
 card.cpp
 Code uses a class file to create playing cards
 Code has been moved from .h to .cpp
*/

// Preprocessing Directives
//#pragma once
#include "card.h"




// cards namespace definition with the cardSuit and CardValue enumerated variables


// card suit and value are private






// card constructor is public
card::card(cards::cardSuit mySuit, cards::cardValue myValue) {
    setCardValue(myValue);
    setCardSuit(mySuit);



    // declare char values for cards
    char charValue;
    char charSuit;
    // switch statements assigns chars based on enumeration
    switch (secretValue) {
    case cards::cardValue::Ace:
        charValue = char(65);
        break;
    case cards::cardValue::Two:
        charValue = char(50);
        break;
    case cards::cardValue::Three:
        charValue = char(51);
        break;
    case cards::cardValue::Four:
        charValue = char(52);
        break;
    case cards::cardValue::Five:
        charValue = char(53);
        break;
    case cards::cardValue::Six:
        charValue = char(54);
        break;
    case cards::cardValue::Seven:
        charValue = char(55);
        break;
    case cards::cardValue::Eight:
        charValue = char(56);
        break;
    case cards::cardValue::Nine:
        charValue = char(57);
        break;
    case cards::cardValue::Ten:
        charValue = char(88);
        break;
    case cards::cardValue::Jack:
        charValue = char(74);
        break;
    case cards::cardValue::Queen:
        charValue = char(81);
        break;
    case cards::cardValue::King:
        charValue = char(75);
        break;
    }
    switch (secretSuit) {
    case cards::cardSuit::heart:
        charSuit = char(3);
        break;
    case cards::cardSuit::diamond:
        charSuit = char(4);
        break;
    case cards::cardSuit::club:
        charSuit = char(5);
        break;
    case cards::cardSuit::spade:
        charSuit = char(6);
        break;
    }


    //literally brute forcing all of the card drawing because i wanted it differently.
    string topPiping = "01234567";
    topPiping[0] = char(201);
    topPiping[1] = char(205);
    topPiping[2] = char(205);
    topPiping[3] = char(205);
    topPiping[4] = char(205);
    topPiping[5] = char(205);
    topPiping[6] = char(205);
    topPiping[7] = char(187);


    string bottomPiping = "01234567";
    bottomPiping[0] = char(200);
    bottomPiping[1] = char(205);
    bottomPiping[2] = char(205);
    bottomPiping[3] = char(205);
    bottomPiping[4] = char(205);
    bottomPiping[5] = char(205);
    bottomPiping[6] = char(205);
    bottomPiping[7] = char(188);



    //edit card info
    string topText = "o      o";
    topText[0] = char(186);
    topText[7] = char(186);
    topText[1] = charValue;
    topText[2] = charSuit;


    string bottomText = "o      o";
    bottomText[0] = char(186);
    bottomText[7] = char(186);
    bottomText[5] = charValue;
    bottomText[6] = charSuit;



    // card is drawn
    // top
    //myCard.cardPiping(myCard);







    cardBuilder[0] = topPiping;
    cardBuilder[1] = topText;



    //234
    if (secretSuit == cards::cardSuit::heart) {
        // heart
        string top = "0 /\\/\\ 7";
        top[0] = char(186);
        top[7] = char(186);
        string mid = "0 \\  / 7";
        mid[0] = char(186);
        mid[7] = char(186);
        string btm = "0  \\/  7";
        btm[0] = char(186);
        btm[7] = char(186);

        cardBuilder[2] = top;
        cardBuilder[3] = mid;
        cardBuilder[4] = btm;
    }
    else if (secretSuit == cards::cardSuit::diamond) {
        // diamons
        // spades
        string top = "0  /\\  7";
        top[0] = char(186);
        top[7] = char(186);
        string mid = "0 <  > 7";
        mid[0] = char(186);
        mid[7] = char(186);
        string btm = "0  \\/  7";
        btm[0] = char(186);
        btm[7] = char(186);

        cardBuilder[2] = top;
        cardBuilder[3] = mid;
        cardBuilder[4] = btm;
    }
    else if (secretSuit == cards::cardSuit::club) {
        // clubs
        // spades
        string top = "0  ()  7";
        top[0] = char(186);
        top[7] = char(186);
        string mid = "0 ()() 7";
        mid[0] = char(186);
        mid[7] = char(186);
        string btm = "0  /\\  7";
        btm[0] = char(186);
        btm[7] = char(186);

        cardBuilder[2] = top;
        cardBuilder[3] = mid;
        cardBuilder[4] = btm;
    }
    else if (secretSuit == cards::cardSuit::spade) {
        // spades
        string top = "0  /\\  7";
        top[0] = char(186);
        top[7] = char(186);
        string mid = "0 (  ) 7";
        mid[0] = char(186);
        mid[7] = char(186);
        string btm = "0  )(  7";
        btm[0] = char(186);
        btm[7] = char(186);

        cardBuilder[2] = top;
        cardBuilder[3] = mid;
        cardBuilder[4] = btm;

    }



    //   string sidePiping = "0      7";
    //   sidePiping[0] = char(186);
    //   sidePiping[7] = char(186);



    cardBuilder[5] = bottomText;
    cardBuilder[6] = bottomPiping;



}

// function sets card value
void card::setCardValue(cards::cardValue inputValue) { // changes value
    secretValue = inputValue;
}

// function sets card value
cards::cardValue card::getCardValue() { // returns value
    return secretValue;
}

// function sets card suit
void card::setCardSuit(cards::cardSuit inputSuit) { // changes suit
    secretSuit = inputSuit;
}

// function sets card value
cards::cardSuit card::card::getCardSuit() { // returns value
    return secretSuit;
}



// master function for card drawing.
std::ostream& operator << (std::ostream& os, card& myCard) { // os is overwritten






    cout << myCard.cardBuilder[0] << endl;
    cout << myCard.cardBuilder[1] << endl;
    cout << myCard.cardBuilder[2] << endl;
    cout << myCard.cardBuilder[3] << endl;
    cout << myCard.cardBuilder[4] << endl;
    cout << myCard.cardBuilder[5] << endl;
    cout << myCard.cardBuilder[6] << endl;
    cout << endl;

    //  os << char(187);
  //  os << char(186);

    /*

       os << char(187) << std::endl;
       // top label
       os << char(186);

       os << charValue << charSuit << ' ';



       //myCard.yBorder(7);
       for (int i = 0; i < 7; i++) {
           os << ' ';
       }

       os << char(186) << std::endl;
       // body


       //myCard.cardMid();
       for (int i = 0; i < 7; i++) {
           os << char(186);
           //yBorder(10);
           for (int i = 0; i < 10; i++) {
               os << ' ';
           }

           os << char(186) << std::endl;
       }


       // bottom label
       os << char(186);

       //myCard.yBorder(7);
       for (int i = 0; i < 7; i++) {
           os << ' ';
       }

       if(myCard.secretValue == cards::cardValue::Ten){
           os << char(49) << charValue << charSuit;
       }else{
           os << ' ' << charValue << charSuit;
       }
       os << char(186) << std::endl;
       // bottom
       os << char(200);

       //myCard.xBorder(10);
       for (int i = 0; i < 10; i++) {
           os << char(205);
       }


       os << char(188) << std::endl;
       */

    return os;
}

// added default constructor
card::card() {

}


// added getters for card int values and int suits
// making my enums typesafe kinda broke everything.
// this is so sad.
int card::valueConvert() {
    int trueValue = 0;
    switch (secretValue) {
    case cards::cardValue::Ace:
        trueValue = 1;
        break;
    case cards::cardValue::Two:
        trueValue = 2;
        break;
    case cards::cardValue::Three:
        trueValue = 3;
        break;
    case cards::cardValue::Four:
        trueValue = 4;
        break;
    case cards::cardValue::Five:
        trueValue = 5;
        break;
    case cards::cardValue::Six:
        trueValue = 6;
        break;
    case cards::cardValue::Seven:
        trueValue = 7;
        break;
    case cards::cardValue::Eight:
        trueValue = 8;
        break;
    case cards::cardValue::Nine:
        trueValue = 9;
        break;
    case cards::cardValue::Ten:
        trueValue = 10;
        break;
    case cards::cardValue::Jack:
        trueValue = 10;
        break;
    case cards::cardValue::Queen:
        trueValue = 10;
        break;
    case cards::cardValue::King:
        trueValue = 10;
        break;
    }
    return trueValue;
}

int card::suitConvert() {
    int trueValue = 0;
    switch (secretSuit) {
    case cards::cardSuit::heart:
        trueValue = 1;
        break;
    case cards::cardSuit::club:
        trueValue = 2;
        break;
    case cards::cardSuit::diamond:
        trueValue = 3;
        break;
    case cards::cardSuit::spade:
        trueValue = 4;
        break;
    }
    return trueValue;
}



