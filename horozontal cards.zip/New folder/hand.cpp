
/*
 Ian Nelson
 CS 361
 Assignment 7
 hand.cpp
 Code uses a class file to create playing cards
*/

// preprocessing
//#pragma once

//#include "card.h"

#include "hand.h"
#include <vector>
using namespace std;


// default constructor
hand::hand() {
}

// adds card to hand
void hand::addCardToHand(card inputCard) {
    handArr.push_back(inputCard);




    int counter = 0;
    int counter2 = 0;
    string current = handArr.at(0).cardBuilder[0];
    while (counter != handArr.size()) {
        while (counter2 != 8) {
            handBuilder.at(counter).at(counter2) = handArr.at(counter).cardBuilder[counter2];
            counter2++;
        }
        counter2 = 0;
        counter++;
    }
    handBuilder.at(0).at(0) = current;

}



// draw a hand on the screen, while loop loops for each card.
void hand::handFormer() {
    int counter = 0;
    int counter2 = 0;

    while (counter != handArr.size()) {
        while (counter2 != 8) {
            handBuilder.at(counter).at(counter2) = handArr.at(counter).cardBuilder[counter2];
            counter2++;
        }
        counter2 = 0;
        counter++;
    }
}

void hand::drawHand() {
    /*int counter = 0;
   while (counter != handArr.size()) {
        cout << handArr[counter];
        counter++;
    }*/

    int counter = 0;
    int counter2 = 0;

    while (counter != 7) {
        while (counter2 != handArr.size()) {
            cout << handBuilder.at(counter2).at(counter);
            counter2++;
        }
        cout << endl;
        counter2 = 0;
        counter++;
    }

}

// returns the lowest value of the hand, while loop checks each card
int hand::handValueLow() {
    int counter = 0;
    int total = 0;
    while (counter != handArr.size()) {
        total = total + handArr[counter].valueConvert();
        counter++;
    }
    return total;
}

// returns the highest value of the hand, while loop checks each card, adds 10 to aces.
int hand::handValueHigh() {
    int counter = 0;
    int total = 0;
    while (counter != handArr.size()) {
        if (handArr[counter].getCardValue() == cards::cardValue::Ace) {
            total = total + 10;
        }
        total = total + handArr[counter].valueConvert();
        counter++;
    }
    return total;
}



