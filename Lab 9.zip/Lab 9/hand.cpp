
// Ian Nelson
// Nov 15th, 2022
// CS 361
// Assignment 8

// hand.cpp: Code uses a class file to create playing cards


// preprocessing
//#pragma once

//#include "card.h"

#include "hand.h"
using namespace std;


// default constructor
hand::hand() {
}

// adds card to hand
void hand::addCardToHand(card inputCard) {
    handArr.push_back(inputCard);

}

// draw a hand on the screen, while loop loops for each card.
void hand::drawHand() {
    int counter = 0;
    while (counter != handArr.size()) {
        cout << handArr[counter];
        counter++;
    }
}

// returns the lowest value of the hand, while loop checks each card
int hand::handValueLow() {
    int counter = 0;
    int total = 0;
    while (counter != handArr.size()) {
        total = total + handArr[counter].valueConvert();
        counter++;
    }
    return total;
}

// returns the highest value of the hand, while loop checks each card, adds 10 to aces.
int hand::handValueHigh() {
    int counter = 0;
    int total = 0;
    while (counter != handArr.size()) {
        if (handArr[counter].getCardValue() == cards::cardValue::Ace) {
            total = total + 10;
        }
        total = total + handArr[counter].valueConvert();
        counter++;
    }
    return total;
}





