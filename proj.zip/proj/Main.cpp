// Ian Nelson
// Dec 4th, 2022
// CS 361
// Assignment 10

// Main.cpp: demonstrates methods created in GList.cpp


#include <iostream>
#include "food.h"
#include "GList.h"
#include <memory>

using namespace std;


// override operators
int main(){
    // create list on heap
    std::unique_ptr<GList> myList(new GList());

    // add food object to list
    food milk;
    milk.publicName = "milk";
    myList->addFood(milk);

    // add food object to list
    food eggs;
    eggs.publicName = "eggs";
    myList->addFood(eggs);

    // add food object to list
    food flour;
    flour.publicName = "flour";
    myList->addFood(flour);

    // add food object to list
    food cheese;
    cheese.publicName = "cheese";
    myList->addFood(cheese);

    // print list
    myList->printList();
    
    // remove element
    myList->subFood();
    
    //print list
    myList->printList();
}