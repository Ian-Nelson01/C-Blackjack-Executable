// Ian Nelson
// Dec 4th, 2022
// CS 361
// Assignment 10

// GList.cpp, creates an std list to store objects, containing strings.


// Preprocessing Directives
#include "GList.h"
#include "food.h"

using namespace std;

// default constructor
GList::GList() {
}

// adds food obj on stack
void GList::addFood(food inputFood){
    foodList.push_back(inputFood);
}

// pops food obj off stack.
void GList::subFood(){
    foodList.pop_back();
    cout << "bussy" << endl; // divides old and new list with an empty line
}

// prints list by iterating.
void GList::printList(){
    // Makes an iterator, loops thru each link of list. Prints.
    for (list<food>::iterator i = foodList.begin(); i != foodList.end(); i++){
         string grabStr = i->publicName; // I think this is a pointer
         cout<< "Your grocery list contains "  << grabStr << "." << endl;
    }                                   
}