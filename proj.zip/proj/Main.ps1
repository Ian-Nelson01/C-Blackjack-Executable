cl /EHsc /I.\headerFiles .\MainX.cpp .\headerFiles\GList.cpp .\headerFiles\Food.cpp
.\MainX.exe